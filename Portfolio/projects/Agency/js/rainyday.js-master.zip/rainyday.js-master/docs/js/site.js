new RainyDay({
  image: 'rainyDayHeader',
  sound: 'sound/rain.mp3'
})
